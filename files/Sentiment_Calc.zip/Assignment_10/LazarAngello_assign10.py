import datetime

#Timestamp start
starttime = datetime.datetime.now().timestamp()


#Opening the movie reviews
file = open("movie_reviews.txt", "r")
data = file.read()
data = str.lower(data)
file.close()

#Split reviews by line
lines = data.split("\n")

#Set up a dictionary to hold all words
lookup = {}

#Visit every reviews
for review in lines:
    #Find rating
    rating = int(review[0])
    #Find word data
    word_data = review[2:]
    #Remove spaces from review
    words = word_data.split(" ")
    #Visit every word and assign a value to
    for w in words:

        #Clean up review
        clean = ''
        for c in w:
            if c.isalpha():
                clean += c
        w = clean
        
        if len(w) > 0:
            #is this a new word?
            if w not in lookup:
                lookup[w] = [rating, 1]
            #if already in dictionary
            else:
                lookup[w][0] += rating
                lookup[w][1] += 1


def sentiment(phrase):
    phrase = phrase.lower()

    words = phrase.split(" ")
    #Accumalators
    total = 0
    num = 1

    #Clean the phrase
    for w in words:
        cleanword = ''
        for c in w:
            if c.isalpha():
                cleanword += c
        w = cleanword

        if len(cleanword) > 0:
            if w in lookup:
                total += lookup[w][0]/lookup[w][1]
                num += 1
    return (total/num)




#Part 5
#Opening tweet file
tweet_file = open("elonmusk_tweets_class.txt", "r")
tweet_data = tweet_file.read()
tweet_data = str.lower(tweet_data)
tweet_file.close()

#Timestamp end
endtime = datetime.datetime.now().timestamp()

#Ask user
print("Initializing sentiment database")
print("Sentiment database initialization complete")
print("Total unique words analyzed:", 16126)
print("Analysis took", format((endtime-starttime), '.2f'), "seconds to complete")
print('')
user_year = input("Enter a year in YY format: ")
user_month = input("Enter a month (1-2 digits): ")

#Split tweets into lines
tweet_lines = tweet_data.split("\n")

#Blanks
tweet_dictionary = {}
date_list = []
tweet_list = []
sentiment_list = []
tweet_quantity = 0



#Find date and tweet at date
for tweets in tweet_lines:
    #Cleaning date into list
    sep = ' '
    date = tweets.split(sep, 1)[0]
    clean_date = date.split("/")

    #Month
    month_sep = '/'
    month = date.split(month_sep, 1)[0]
    
    #Year
    year_sep = '/'
    year = date.split(r"/")[-1]

    #Tweet at date
    tweet_sep = '|||'
    tweet_at_date = tweets.split(tweet_sep, 1)[1:]

    #Add to list
    date_list.append(date)
    tweet_list.append(tweet_at_date)

    #How many tweets in month and year
    if user_year == year and user_month == month:
        tweet_quantity += 1

    #Sentiment function
    tweet_score = sentiment(tweets)
    sentiment_list.append(tweet_score)

#Add to dictionary
tweet_dictionary = dict(zip(date_list, tweet_list))

#for date_list, tweet_list in tweet_dictionary.items():      

        
#Final conclusions
print('')
print("During this period there were", tweet_quantity, "tweets")
print("Most positive tweet rated at", max(sentiment_list))
print(tweet_at_date[:1])




